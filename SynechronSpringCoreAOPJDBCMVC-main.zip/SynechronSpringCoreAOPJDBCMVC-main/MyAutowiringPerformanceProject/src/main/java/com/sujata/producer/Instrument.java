package com.sujata.producer;

public interface Instrument {

	public void play();
}
