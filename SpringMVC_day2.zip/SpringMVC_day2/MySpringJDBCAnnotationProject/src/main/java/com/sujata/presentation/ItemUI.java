package com.sujata.presentation;

public interface ItemUI {

	public void showMenu();
	public void perform(int choice);
}
